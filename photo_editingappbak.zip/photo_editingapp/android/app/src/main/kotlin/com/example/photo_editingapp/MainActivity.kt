package com.photo_editingapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
